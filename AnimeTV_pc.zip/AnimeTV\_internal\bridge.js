// Мост для режима телевизора: вызовы pywebview.api.* идут на ПК по HTTP
const __PC__ = new URLSearchParams(location.search).has('pc');  // ПК в браузере (запасной режим)
window.__TV__ = !__PC__;
window.pywebview = {
  api: new Proxy({}, {
    get: (_, name) => (...args) => {
      if (name === 'toggle_fullscreen') {
        if (document.fullscreenElement) document.exitFullscreen(); else document.documentElement.requestFullscreen().catch(() => {});
        return Promise.resolve(null);
      }
      if (name === 'open_link') { if (__PC__) window.open(args[0], '_blank'); else if (window.toast) toast('Открой это на телефоне или ПК'); return Promise.resolve(null); }
      if (name === 'exit_fullscreen') { if (document.fullscreenElement) document.exitFullscreen(); return Promise.resolve(false); }
      return fetch('/api/' + name, { method: 'POST', body: JSON.stringify(args) })
        .then(r => r.json()).catch(e => ({ error: 'нет связи с ПК' }));
    }
  })
};
window.addEventListener('load', () => setTimeout(() => window.dispatchEvent(new Event('pywebviewready')), 50));
